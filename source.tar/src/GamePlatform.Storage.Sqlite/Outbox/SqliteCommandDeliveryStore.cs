#nullable enable
using System;
using System.Threading;
using System.Threading.Tasks;
using GamePlatform.Core;
using GamePlatform.Storage.Abstractions;
using GamePlatform.Storage.Abstractions.Outbox;
using GamePlatform.Storage.Sqlite.Executor;

namespace GamePlatform.Storage.Sqlite.Outbox
{
    public sealed class SqliteCommandDeliveryStore : ICommandDeliveryStore
    {
        private readonly SqliteDatabase database; private readonly StorageScope scope;
        public SqliteCommandDeliveryStore(SqliteDatabase database, StorageScope scope)
        {
            this.database = database ?? throw new ArgumentNullException(nameof(database));
            this.scope = scope;
            if (!database.Scope.Equals(scope))
                throw new StorageException(StorageFailure.InvalidOwner, "The delivery scope does not match the database.");
        }
        public Task<LeasedCommand?> LeaseNextAsync(long nowMilliseconds, long leaseMilliseconds, CancellationToken cancellationToken)
        {
            if (nowMilliseconds < 0 || nowMilliseconds > 253_402_300_799_999L || leaseMilliseconds < 1 || leaseMilliseconds > 86_400_000 || nowMilliseconds > 253_402_300_799_999L - leaseMilliseconds)
                throw new ArgumentOutOfRangeException();
            var until = nowMilliseconds + leaseMilliseconds;
            return database.ExecuteAsync(scope, transaction => { var s = (SqliteTransactionSession)transaction; var finalized = s.ExecuteScalar<long>("SELECT finalized_through FROM gp_stream_state WHERE singleton = 1 AND ready = 1"); if (finalized == long.MaxValue) return null; var sequence = finalized + 1; var count = s.ExecuteScalar<int>("SELECT COUNT(*) FROM gp_outbox WHERE sequence = ? AND (delivery_state = 'pending' OR (delivery_state = 'in_flight' AND leased_until <= ?))", sequence, nowMilliseconds); if (count == 0) return null; s.Execute("UPDATE gp_outbox SET delivery_state = 'in_flight', leased_until = ? WHERE sequence = ?", until, sequence); var operation = new OperationId(Guid.Parse(s.ExecuteScalar<string>("SELECT operation_id FROM gp_outbox WHERE sequence = ?", sequence))); var stream = new ClientStreamId(Guid.Parse(s.ExecuteScalar<string>("SELECT client_stream_id FROM gp_outbox WHERE sequence = ?", sequence))); var installation = Guid.Parse(s.ExecuteScalar<string>("SELECT installation_id FROM gp_outbox WHERE sequence = ?", sequence)); return new LeasedCommand(operation, stream, installation, sequence, s.ExecuteScalar<string>("SELECT operation_kind FROM gp_outbox WHERE sequence = ?", sequence), s.ExecuteScalar<int>("SELECT schema_version FROM gp_outbox WHERE sequence = ?", sequence), s.ExecuteScalar<int>("SELECT fingerprint_version FROM gp_outbox WHERE sequence = ?", sequence), s.ExecuteScalar<long>("SELECT client_created_at FROM gp_outbox WHERE sequence = ?", sequence), s.ExecuteScalar<byte[]>("SELECT semantic_body FROM gp_outbox WHERE sequence = ?", sequence), s.ExecuteScalar<byte[]>("SELECT fingerprint FROM gp_outbox WHERE sequence = ?", sequence)); }, cancellationToken);
        }
        public Task FinalizeAsync(OperationId operationId, long sequence, CommandTerminalOutcome outcome, byte[]? terminalResult, CancellationToken cancellationToken)
        {
            if (!operationId.IsValid || sequence <= 0 || (terminalResult?.Length ?? 0) > 65_536)
                throw new ArgumentException("Invalid terminal outcome.");
            var copy = terminalResult == null ? null : (byte[])terminalResult.Clone();
            return database.ExecuteAsync(scope, transaction => { var s = (SqliteTransactionSession)transaction; var expected = s.ExecuteScalar<long>("SELECT finalized_through + 1 FROM gp_stream_state WHERE singleton = 1"); if (expected != sequence || s.ExecuteScalar<int>("SELECT COUNT(*) FROM gp_outbox WHERE operation_id = ? AND sequence = ? AND delivery_state = 'in_flight'", operationId.ToString(), sequence) != 1) throw new StorageException(StorageFailure.StreamRecoveryRequired, "The terminal outcome is not the next leased command."); s.Execute("UPDATE gp_outbox SET delivery_state = ?, leased_until = NULL, terminal_result = ? WHERE operation_id = ?", outcome == CommandTerminalOutcome.Accepted ? "accepted" : "terminal_rejected", copy, operationId.ToString()); s.Execute("UPDATE gp_stream_state SET finalized_through = ? WHERE singleton = 1", sequence); return true; }, cancellationToken);
        }
        public Task ReleaseAsync(OperationId operationId, long sequence, CancellationToken cancellationToken)
        {
            if (!operationId.IsValid || sequence <= 0)
                throw new ArgumentException("Invalid command identity.");
            return database.ExecuteAsync(scope, transaction => { var s = (SqliteTransactionSession)transaction; s.Execute("UPDATE gp_outbox SET delivery_state = 'pending', leased_until = NULL WHERE operation_id = ? AND sequence = ? AND delivery_state = 'in_flight'", operationId.ToString(), sequence); return true; }, cancellationToken);
        }
    }
}
